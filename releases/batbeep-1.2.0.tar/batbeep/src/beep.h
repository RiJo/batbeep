#ifndef _BEEP_H_
#define _BEEP_H_ 1

void beep(float, unsigned int, unsigned int, unsigned int);

#endif