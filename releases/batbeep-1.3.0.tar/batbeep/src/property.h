#include "hashmap.h"

#ifndef PROPERTY_H
#define PROPERTY_H 1

void load_file(hashmap *, char *);
void load_properties(hashmap *, FILE *);

#endif