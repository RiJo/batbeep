#ifndef DAEMON_H
#define DAEMON_H 1

int daemonize(char *);

#endif