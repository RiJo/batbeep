--------------------------------------------------------------------------------

   batbeep
   current version:     1.1.0
   by:                  Rikard Johansson

--------------------------------------------------------------------------------
 version 1.0.0, 2010-03-08
--------------------------------------------------------------------------------
    * batbeepd (init script)
    * Arguments
        -d (debug)
        --debug
        -v (version)
        --version
        -h (help)
        --help
    * Available settings
        acpi location (+keys for properties)
        poll timeout
        warning level
        warning frequency
        warning duration
        warning timeout
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
 version 1.1.0, 2010-03-09
--------------------------------------------------------------------------------
    * New arguments
        -b (beep)
        --beep
    * Improved sleep timeout (greatest common divisor)
--------------------------------------------------------------------------------