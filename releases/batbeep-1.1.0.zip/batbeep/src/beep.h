#ifndef BEEP_H
#define BEEP_H 1

void beep(int, int);

#endif