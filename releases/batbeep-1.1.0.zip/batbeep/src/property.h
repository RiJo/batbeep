#include "hashmap.h"

#ifndef PROPERTY_H
#define PROPERTY_H

void load_file(hashmap *, char *);
void load_properties(hashmap *, FILE *);

#endif