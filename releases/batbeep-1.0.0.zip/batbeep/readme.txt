--------------------------------------------------------------------------------

   batbeep
   current version:     1.0.0
   by:                  Rikard Johansson

--------------------------------------------------------------------------------
 version 1.0.0, 2010-03-08
--------------------------------------------------------------------------------
    * batbeepd (init script)
    * Parameters
        -d (debug)
        --debug
        -v (version)
        --version
        -h (help)
        --help
    * Available settings
        acpi location (+keys for properties)
        poll timeout
        warning level
        warning frequency
        warning duration
        warning timeout
--------------------------------------------------------------------------------