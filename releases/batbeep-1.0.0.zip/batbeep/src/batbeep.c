/*
    Todo
        * Several different warnings in .settings(?)
        * debug output/beeps
*/


#define _XOPEN_SOURCE 500 /* Or: #define _BSD_SOURCE (for usleep) */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <unistd.h> /* usleep() */
#include <getopt.h> /* getopt_long() */

#include "daemon.h"
#include "property.h"
#include "hashmap.h"
#include "beep.h"

#define PROGRAM_NAME "batbeep"
#define PROGRAM_VERSION "1.0.0"
#define PID_FILE "/var/run/" PROGRAM_NAME ".pid"
#define SETTINGS_FILE "/etc/" PROGRAM_NAME ".conf"

#define BUFFER_SIZE 255
#define SLEEP(ms) usleep(ms*1000)

hashmap *settings = NULL;
hashmap *batt_info = NULL;

void cleanup() {
    hm_delete(settings, NULL);
    hm_delete(batt_info, NULL);
}

void sigint_received(int sig) {
    fprintf(stderr, "\n\nInterrupted...\n\n");
    cleanup();
    exit(sig);
}

/*struct measure *to_measure(char string[]) {
    struct measure *result = malloc(sizeof(struct measure));
    register unsigned int i = 0;
    assert(result);
    result->value = 0;
    while ( string[i] != ' ' ) {
        if ( (string[i] >= 48) & (string[i] <= 57) ) {
            result->value *= 10;
            result->value += (0xF & string[i]);
        }
        i++;
    }
    strcpy(result->unit, &(string[i]));
    return result;
}*/

void assure_key(hashmap *map, char *key) {
    if(!hm_isset(map, key)) {
        fprintf(stderr, "Error: Could not find the key \"%s\"\n", key);
        hm_dump(map, stderr, NULL);
        exit(EXIT_FAILURE);
    }
}

void to_string(FILE *output, char *key, void *value) {
    fprintf(output, "%-30s%s\n", key, (char *)value);
}

void debug_print() {
    printf("%s, version %s\n", PROGRAM_NAME, PROGRAM_VERSION);
    printf("   compiled %s, %s\n\n", __DATE__, __TIME__);
    printf("Entering debug mode (non daemon)...\n\n");
    printf("%s:\n", SETTINGS_FILE);
    hm_print(settings, stdout, to_string);
    printf("\nStarting poll...\n");
}

void print_help() {
    printf("Usage: %s [-d] [-h] [-v]\n", PROGRAM_NAME);
    printf("Continously beeps system speaker when battery is below certain level\n\n");
    printf("  -h, --help                 display this help and exit\n");
    printf("  -d, --debug                print debugging messages (non daemon)\n");
    printf("  -v, --version              output version information and exit\n");
    exit(EXIT_SUCCESS);
}

void print_version() {
    printf("%s, version %s\n", PROGRAM_NAME, PROGRAM_VERSION);
    printf("   compiled %s, %s\n\n", __DATE__, __TIME__);
    printf("Rikard Johansson, 2010\n");
    exit(EXIT_SUCCESS);
}

void print_usage() {
    printf("Usage: %s [-d] [-h] [-v]\n", PROGRAM_NAME);
    printf("Try '%s --help' for more information.\n", PROGRAM_NAME);
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv) {
    (void) signal(SIGINT, sigint_received);

    int debugging = 0;

    struct option opt_list[] = {
        {"help",    0, NULL, 'h'},
        {"version", 0, NULL, 'v'},
        {"debug",   0, NULL, 'd'},
        {0,0,0,0}
    };
    int arg;
    while((arg = getopt_long(argc, argv, "hvd", opt_list, NULL)) != EOF) {
        switch (arg) {
            case 'h':
                print_help();
                break;
            case 'v':
                print_version();
                break;
            case 'd':
                debugging = 1;
                break;
            default:
                print_usage();
                break;
        }
    }

    settings = hm_create(10, 0.5, 7);
    batt_info = hm_create(10, 0.5, 7);

    load_file(settings, SETTINGS_FILE);

    assure_key(settings, "acpi_location");
    assure_key(settings, "poll_timeout");
    assure_key(settings, "warning_level");
    assure_key(settings, "warning_frequency");
    assure_key(settings, "warning_duration");
    assure_key(settings, "warning_timeout");
    assure_key(settings, "bat_state");
    assure_key(settings, "bat_capacity");
    assure_key(settings, "bat_remaining");

    unsigned int poll_timeout = atoi(hm_get(settings, "poll_timeout"));
    unsigned int warning_level = atoi(hm_get(settings, "warning_level"));
    unsigned int warning_frequency = atoi(hm_get(settings, "warning_frequency"));
    unsigned int warning_duration = atoi(hm_get(settings, "warning_duration"));
    unsigned int warning_timeout = atoi(hm_get(settings, "warning_timeout"));

    char acpi[BUFFER_SIZE], acpi_alarm[BUFFER_SIZE], acpi_info[BUFFER_SIZE], acpi_state[BUFFER_SIZE];
    strcpy(acpi, hm_get(settings, "acpi_location"));
    strcpy(acpi_alarm, acpi);
    strcat(acpi_alarm, "/alarm\0");
    strcpy(acpi_info, acpi);
    strcat(acpi_info, "/info\0");
    strcpy(acpi_state, acpi);
    strcat(acpi_state, "/state\0");

    if (debugging) {
        debug_print();
    }
    else if (!daemonize(PID_FILE)) {
        exit(EXIT_FAILURE);
    }

    unsigned int i = 0;
    while (1) {
        load_file(batt_info, acpi_alarm);
        load_file(batt_info, acpi_info);
        load_file(batt_info, acpi_state);

        assure_key(batt_info, hm_get(settings, "bat_state"));
        assure_key(batt_info, hm_get(settings, "bat_capacity"));
        assure_key(batt_info, hm_get(settings, "bat_remaining"));

        char *bat_state = hm_get(batt_info, hm_get(settings, "bat_state"));
        char *bat_capacity = hm_get(batt_info, hm_get(settings, "bat_capacity"));
        char *bat_remaining = hm_get(batt_info, hm_get(settings, "bat_remaining"));
        float capacity_factor = (float)atoi(bat_remaining) / (float)atoi(bat_capacity);

        if (poll_timeout * ++i >= warning_timeout) {
            i = 0;
            if (capacity_factor <= (float)warning_level / 100.0 && strcmp(bat_state, "discharging") == 0) {
                beep(warning_frequency, warning_duration);
            }
            if (debugging) {
                printf("Capacity: %.2f%%\tState: %s\n", capacity_factor * 100, bat_state);
            }
        }

        SLEEP(poll_timeout);
    }

    cleanup();

    return EXIT_SUCCESS;
}